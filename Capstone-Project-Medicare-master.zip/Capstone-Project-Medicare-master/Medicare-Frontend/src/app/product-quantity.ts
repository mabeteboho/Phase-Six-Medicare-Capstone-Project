import { Product } from "./product";

export class ProductQuantity {
    pqid!: number;
    product!: Product;
    quantity!: number;
}